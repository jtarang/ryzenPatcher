//This dummy header file is created for mig to check when to include voucher code.
//Mig checks if this file is available to include and knows that Libsyscall has the new voucher symbols to link to.
//Do not delete this file, mig will stop including vouchers code.

#ifndef __MACH_MIG_VOUCHER_SUPPORT__
#define __MACH_MIG_VOUCHER_SUPPORT__

#endif // __MACH_MIG_VOUCHER_SUPPORT__
